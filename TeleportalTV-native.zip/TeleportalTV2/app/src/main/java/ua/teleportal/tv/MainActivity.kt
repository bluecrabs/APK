package ua.teleportal.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val HOME = "https://teleportal.ua/"
        private const val ORIGIN = "https://teleportal.ua"
    }

    private class Level(val title: String, val items: List<Item>, var pos: Int = 0)

    private lateinit var scraper: Scraper
    private lateinit var list: ListView
    private lateinit var header: TextView
    private lateinit var status: TextView
    private val stack = ArrayList<Level>()
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        // Скрытый «рендерер» сайта — лежит под интерфейсом, на весь экран (нужен нормальный viewport)
        val web = WebView(this)
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        scraper = Scraper(web)

        val ui = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF10142B.toInt())
            setPadding(dp(48), dp(24), dp(48), dp(16))
        }
        header = TextView(this).apply { textSize = 28f; setTextColor(Color.WHITE) }
        status = TextView(this).apply { textSize = 16f; setTextColor(0xFF9AA0C0.toInt()) }
        list = ListView(this).apply {
            divider = null
            selector = ColorDrawable(0x66FF4D6D)
            isFocusable = true
            setOnItemClickListener { _, _, pos, _ -> onItem(pos) }
        }
        ui.addView(header)
        ui.addView(status)
        ui.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(ui, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        loadRoot()
    }

    // ---------- Навигация ----------

    private fun setBusy(b: Boolean, text: String = "") {
        busy = b
        status.text = if (b) text else "OK — открыть, Назад — вернуться, MENU — лог запросов"
    }

    private fun loadRoot() {
        setBusy(true, "Загружаю меню…")
        scraper.load(HOME, expectStream = false) { res ->
            setBusy(false)
            val items = res.menu + res.cards
            stack.clear()
            if (items.isEmpty()) {
                stack.add(Level("Teleportal", listOf(Item("Ничего не найдено — повторить", HOME))))
            } else stack.add(Level("Teleportal", items))
            render()
        }
    }

    private fun onItem(pos: Int) {
        if (busy) return
        val lvl = stack.last()
        val item = lvl.items.getOrNull(pos) ?: return
        if (stack.size == 1 && lvl.items.size == 1 && item.url == HOME) { loadRoot(); return }
        lvl.pos = pos
        setBusy(true, "Загружаю «${item.title}»…")
        scraper.load(item.url, expectStream = true) { res ->
            setBusy(false)
            when {
                res.streams.isNotEmpty() -> showStreams(item.title, res.streams)
                res.cards.isNotEmpty() || res.menu.isNotEmpty() -> {
                    // в подразделах меню сайта не повторяем
                    stack.add(Level(item.title, res.cards.ifEmpty { res.menu }))
                    render()
                }
                else -> Toast.makeText(this, "Ничего не найдено (MENU — лог)", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun render() {
        val lvl = stack.last()
        header.text = stack.joinToString(" › ") { it.title }.takeLast(80)
        list.adapter = object : ArrayAdapter<Item>(this, android.R.layout.simple_list_item_1, lvl.items) {
            override fun getView(p: Int, c: View?, parent: ViewGroup): View {
                val v = super.getView(p, c, parent) as TextView
                v.text = lvl.items[p].title
                v.setTextColor(Color.WHITE)
                v.textSize = 22f
                v.setPadding(dp(16), dp(12), dp(16), dp(12))
                return v
            }
        }
        list.setSelection(lvl.pos)
        list.requestFocus()
        setBusy(false)
    }

    override fun onBackPressed() {
        when {
            busy -> { scraper.cancel(); setBusy(false) }
            stack.size > 1 -> { stack.removeAt(stack.size - 1); render() }
            else -> super.onBackPressed()
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { showLog(); return true }
        return super.onKeyUp(keyCode, event)
    }

    // ---------- Потоки и внешний плеер ----------

    private fun showStreams(title: String, streams: List<String>) {
        if (streams.size == 1) { play(title, streams[0]); return }
        val labels = streams.map { it.substringAfter("://").take(90) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Найдено потоков: ${streams.size} (часть может быть рекламой)")
            .setItems(labels) { _, i -> play(title, streams[i]) }
            .setNeutralButton("Копировать все") { _, _ -> copy(streams.joinToString("\n")) }
            .show()
    }

    private fun play(title: String, url: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), "application/x-mpegURL")
            putExtra("title", title)
            // MX Player и совместимые принимают заголовки таким образом
            putExtra("headers", arrayOf("User-Agent", Scraper.UA, "Referer", "$ORIGIN/", "Origin", ORIGIN))
        }
        try {
            startActivity(Intent.createChooser(intent, "Открыть в плеере"))
        } catch (e: ActivityNotFoundException) {
            copy(url)
            Toast.makeText(this, "Нет внешнего плеера (VLC, MX Player). Ссылка скопирована.", Toast.LENGTH_LONG).show()
        }
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", text))
    }

    private fun showLog() {
        val tv = TextView(this).apply {
            text = scraper.logText().ifEmpty { "(пусто)" }
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        AlertDialog.Builder(this).setTitle("Последние сетевые запросы")
            .setView(android.widget.ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Закрыть", null).show()
    }
}

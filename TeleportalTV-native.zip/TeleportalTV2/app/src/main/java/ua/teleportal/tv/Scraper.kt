package ua.teleportal.tv

import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener

data class Item(val title: String, val url: String)
class Result(val streams: List<String>, val menu: List<Item>, val cards: List<Item>)

/**
 * Скрытый WebView: рендерит страницу (сайт — SPA), вытаскивает из DOM меню и карточки
 * и перехватывает сетевые запросы к .m3u8.
 */
class Scraper(private val web: WebView) {

    companion object {
        const val UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
        private const val MAX_WAIT_MS = 12000

        // Достаём ссылки меню (header/nav) и карточки контента (остальные ссылки того же сайта)
        private const val EXTRACT_JS = """
(function(){
  var host=location.hostname.split('.').slice(-2).join('.');
  var here=location.href.split('#')[0], seen={}, menu=[], cards=[];
  function title(a){
    var t=(a.innerText||a.textContent||'').trim().replace(/\s+/g,' ');
    if(!t){var i=a.querySelector('img'); if(i) t=i.alt||i.title||'';}
    if(!t) t=a.getAttribute('title')||a.getAttribute('aria-label')||'';
    return t;
  }
  function push(arr,a){
    var h=a.href; if(!h||!/^https?:/.test(h)) return;
    var u; try{u=new URL(h);}catch(e){return;}
    if(u.hostname.indexOf(host)<0) return;
    if(h.split('#')[0]===here) return;
    var t=title(a); if(!t||t.length<2||seen[h]) return;
    seen[h]=1; arr.push({t:t.slice(0,90),u:h});
  }
  document.querySelectorAll('header a[href], nav a[href]').forEach(function(a){push(menu,a);});
  document.querySelectorAll('a[href]').forEach(function(a){
    if(a.closest('header,nav,footer')) return; push(cards,a);
  });
  return JSON.stringify({menu:menu,cards:cards});
})()
"""
        private const val PLAY_JS = """
(function(){
  var v=document.querySelector('video');
  if(v){v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}
  var b=document.querySelector('.vjs-big-play-button,[class*=play-btn],[class*=PlayButton],[aria-label*=lay]');
  if(b)b.click();
})()
"""
        private const val HAS_PLAYER_JS = "(!!document.querySelector('video'))"
    }

    private val h = Handler(Looper.getMainLooper())
    private val m3u8 = LinkedHashSet<String>()
    private val netLog = ArrayList<String>()
    private var token = 0

    init {
        web.isFocusable = false
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = UA
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url.toString()
                synchronized(netLog) {
                    if (u.contains(".m3u8")) { m3u8.add(u); netLog.add("[HLS] $u") }
                    else if (u.contains("/api/") || u.contains(".json") || u.contains(".mpd"))
                        netLog.add("[API] $u")
                    if (netLog.size > 120) netLog.removeAt(0)
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme
                return s != "http" && s != "https"
            }
        }
    }

    fun cancel() { token++; web.stopLoading() }

    fun logText(): String = synchronized(netLog) { netLog.takeLast(40).joinToString("\n") }

    fun load(url: String, expectStream: Boolean, cb: (Result) -> Unit) {
        val my = ++token
        synchronized(netLog) { m3u8.clear() }
        web.stopLoading()
        web.loadUrl(url)

        var elapsed = 0
        var firstFound = -1
        var done = false
        var checking = false

        fun deliver(streams: List<String>) {
            if (done || my != token) return
            done = true
            if (streams.isNotEmpty()) { cb(Result(streams, emptyList(), emptyList())); return }
            web.evaluateJavascript(EXTRACT_JS) { raw ->
                if (my != token) return@evaluateJavascript
                val (m, c) = parse(raw)
                cb(Result(emptyList(), m, c))
            }
        }

        val tick = object : Runnable {
            override fun run() {
                if (done || my != token) return
                elapsed += 500
                val found = synchronized(netLog) { m3u8.toList() }

                if (expectStream && found.isNotEmpty()) {
                    if (firstFound < 0) firstFound = elapsed
                    // ждём ещё 2.5 c, чтобы собрать все варианты (реклама / основной поток)
                    if (elapsed - firstFound >= 2500) { deliver(found); return }
                }
                if (elapsed == 3000 || elapsed == 7000) web.evaluateJavascript(PLAY_JS, null)

                if (elapsed >= MAX_WAIT_MS) { deliver(if (expectStream) found else emptyList()); return }

                if (!expectStream && elapsed >= 4000) { deliver(emptyList()); return }

                // Нет <video> -> это страница-список, не ждём весь таймаут
                if (expectStream && elapsed >= 3000 && firstFound < 0 && !checking) {
                    checking = true
                    web.evaluateJavascript(HAS_PLAYER_JS) { r ->
                        checking = false
                        if (r != "true") deliver(emptyList())
                    }
                }
                h.postDelayed(this, 500)
            }
        }
        h.postDelayed(tick, 500)
    }

    private fun parse(raw: String?): Pair<List<Item>, List<Item>> {
        val none = Pair(emptyList<Item>(), emptyList<Item>())
        if (raw == null || raw == "null") return none
        return try {
            val o = JSONObject(JSONTokener(raw).nextValue() as String)
            fun arr(k: String): List<Item> {
                val a = o.getJSONArray(k)
                return (0 until a.length()).map {
                    val e = a.getJSONObject(it); Item(e.getString("t"), e.getString("u"))
                }
            }
            Pair(arr("menu"), arr("cards"))
        } catch (e: Exception) { none }
    }
}

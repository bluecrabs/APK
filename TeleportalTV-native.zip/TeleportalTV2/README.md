# Teleportal TV (native)

Нативный список «меню → разделы → видео». Страницы рендерит скрытый WebView, из DOM берутся
меню и карточки, из сети перехватываются HLS (.m3u8). Воспроизведение — во внешнем плеере (VLC, MX Player…).

Управление: стрелки/OK — выбор, Назад — вернуться, MENU — лог перехваченных запросов.
Сборка: Android Studio (Build APK) или GitHub Actions (.github/workflows/build.yml).
